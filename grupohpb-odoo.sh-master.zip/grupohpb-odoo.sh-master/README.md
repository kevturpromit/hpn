# grupohpb-odoo.sh
